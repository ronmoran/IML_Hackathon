classifier.py - a python file contain code for training the classifiers and using it
data_splitter.py - a python file that splits the given data into train, validation and test
location_predictor.py - a python file containing code that given data learns the best combinations
			of location and time
Q1_model.pkl - a model for the first part of the exercise
Q2_model.npy - a model for the second part of the exercise
Beat.pkl - pickle origin file
District.pkl - pickle origin file
Domestic.pkl - pickle origin file
Location_Descriptor.pkl - pickled origin file
Ward.pkl - pickle origin file